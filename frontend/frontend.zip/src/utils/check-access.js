export const checkAcess = (access, userRole) => access.includes(userRole);

