import { ACTION_TYPE } from "./action-type";

export const CLOSE_MODAL={
   type: ACTION_TYPE.CLOSE_MODAL,
}