import { ACTION_TYPE } from "./action-type";

export const RESET_POST_DATA = {
   type: ACTION_TYPE.RESET_POST_DATA

}