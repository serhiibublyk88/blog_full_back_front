export const selectModalOnCencel = ({ app }) => app.modal.onCencel;
