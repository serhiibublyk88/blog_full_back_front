export const selectUserRole=({user})=>user.roleId;
