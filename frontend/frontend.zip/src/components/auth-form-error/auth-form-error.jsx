import styled from "styled-components";

export const AuthFormError = styled.div`
  background-color: #fcadad;
  font-size: 18px;
  margin: 10px 0 0;
  padding: 10px;
`;
