export * from "./header/header.jsx";
export * from "./icon/icon.jsx"
export * from "./footer/footer.jsx"
export * from "./input/input.jsx"
export * from "./button/button.jsx"
export * from "./h2/h2.jsx"
export * from "./auth-form-error/auth-form-error.jsx"
export * from "./private-content/private-content.jsx"
export * from "./modal/modal.jsx"
export * from "./error/error.jsx"
 