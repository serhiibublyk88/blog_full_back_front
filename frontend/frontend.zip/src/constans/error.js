export const ERROR = {
  PAGE_NOT_EXIST: "Page not exist.",
  ACCESS_DENIED: "Access denied.",
};
