export const ROLE = {
  ADMIN: 0,
  MODERATOR: 1,
  READER: 2,
  GUEST: 3,
};
